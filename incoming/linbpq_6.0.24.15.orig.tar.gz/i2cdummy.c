/*
Copyright 2001-2015 John Wiseman G8BPQ

This file is part of LinBPQ/BPQ32.

LinBPQ/BPQ32 is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

LinBPQ/BPQ32 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with LinBPQ/BPQ32.  If not, see http://www.gnu.org/licenses
*/	

#include "CHeaders.h"
#include "tncinfo.h"




//int SENDNODES() {return 0;}
//int BYECMD() {return 0;}
//int CMDR00() {return 0;}

//int DoNetromConnect() {return 0;}


//int CMDC00() {return 0;}



//int CheckReceivedData() {return 0;}
//int GetLastError() {return 0;}



VOID i2c_smbus_write_byte()
{
}

VOID i2c_smbus_read_byte()
{
}
