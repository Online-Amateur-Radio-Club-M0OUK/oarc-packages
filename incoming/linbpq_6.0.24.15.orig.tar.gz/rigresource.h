//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RigControl.rc
//


#define ID_ADDRIG                       3
#define ID_ADDTIME                      4
#define RIG_MENU1                       103
#define IDC_TIMES                       1014
#define IDC_RIGTYPE                     1015
#define IDC_COMPORT                     1016
#define IDC_FREQ                        1017
#define IDC_SPEED                       1018
#define IDC_ADDR                        1019
#define IDC_ADDR2                       1020
#define IDC_DISPTIMES                   1021
#define IDC_DISPFREQ                    1022
#define IDC_RADIO1                      1023
#define RIG_LINE                        1024
#define RIGCONFIG                       30016
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
