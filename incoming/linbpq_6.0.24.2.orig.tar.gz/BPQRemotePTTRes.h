//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BPQRemotePTT.rc
//
#define IDC_BPQHOST                     1000
#define IDC_COM1                        1001
#define IDC_HAMLIBPORT1                 1002
#define IDC_COM2                        1003
#define IDC_STATE1                      1004
#define IDC_TEST1                       1005
#define IDC_HAMLIBPORT2                 1006
#define IDC_STATE2                      1007
#define IDC_TEST2                       1008
#define IDC_COM3                        1009
#define IDC_HAMLIBPORT3                 1010
#define IDC_STATE3                      1011
#define IDC_TEST3                       1012
#define IDC_COM4                        1013
#define IDC_HAMLIBPORT4                 1014
#define IDC_STATE4                      1015
#define IDC_TEST4                       1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
