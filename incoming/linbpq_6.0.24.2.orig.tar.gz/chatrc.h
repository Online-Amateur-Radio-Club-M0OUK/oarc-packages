//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BPQChat.rc
//

#define IDC_NODES 501
#define IDC_USERS 502
#define IDC_LINKS 503

#define MONBBS 1060
#define MONCHAT 1061
#define MONTCP 1062


#define IDS_APP_TITLE 103
#define IDC_BPQMailChat 109

#define CHAT_CONFIG 9013

#define IDC_UTC 506
#define IDC_LOCAL 507

#define BPQBASE 1024
#define BPQMTX 1040
#define BPQMCOM 1041
#define BPQCOPYMON 1042
#define BPQCOPYOUT 1043
#define BPQCLEARMON 1044
#define BPQCLEAROUT 1045
#define BPQBELLS 1046
#define BPQCHAT 1047
#define BPQHELP 1048
#define BPQStripLF 1049
#define BPQLogOutput 1050
#define BPQLogMonitor 1051
#define BPQSendDisconnected 1052
#define BPQFLASHONBELL 1053


#define IDSENDTOMAP                     3
#define IDI_ICON1                       101
#define IDM_CONFIG 110
#define IDM_MONITOR 121
#define IDM_ABOUT 104
#define IDD_PROPPAGE_LARGE              107
#define IDC_NODES2                      505
#define IDC_MAXSEND                     506
#define IDC_MAXRECV                     507
#define IDC_MAXBLOCK                    508
#define IDC_BBSHA                       509
#define IDC_SMTP                        510
#define IDC_USERS2                      513
#define IDC_MSGSEM                      514
#define IDC_ALLOCSEM                    515
#define IDC_CONSEM                      517
#define IDC_REMOVED                     1006
#define IDC_KILLED                      1007
#define IDC_LIVE                        1008
#define IDC_TOTAL                       1009
#define IDC_BIDSREMOVED                 1010
#define IDC_UIPORTS                     1010
#define IDC_NNTPPort                    1010
#define IDC_BIDSLEFT                    1011
#define IDC_ENABLEUI                    1012
#define IDC_USEB2                       1013
#define IDC_REFUSEBULLS                 1013
#define IDC_CHATSEM                     1014
#define IDC_PERSONALONLY                1014
#define MAILFOR_MINS                    1014
#define IDC_SENDNEW                     1015
#define IDC_UICONFIG                    1016
#define IDC_DELETETORECYCLE             1017
#define IDC_MAINTNOMAIL                 1018
#define IDC_EDIT1                       1019
#define IDC_MSGTO                       1020
#define IDC_WPVIA                       1020
#define IDC_MSGTITLE                    1021
#define IDC_MAINTSAVEREG                1021
#define IDC_MSGBID                      1022
#define IDC_MAINTNONDELIVERY            1022
#define IDSEND                          1023
#define IDCANCELMSG                     1024
#define IDC_ALIAS                       1025
#define IDC_HRTEXT                      1027
#define IDC_HROUTESP                    1029
#define IDC_LASTLISTED                  1030
#define IDC_MESSAGE                     1031
#define IDSAVE                          1032
#define IDM_USERMSG                     1034
#define IDM_CHATUSERMSG                 1035
#define IDM_NEWUSERMSG                  1036
#define IDM_MSGSAVE                     1037
#define IDM_EXPERTUSERMSG               1038
#define IDC_MAPPOSITION                 1039
#define IDC_HOVER                       1040
#define IDC_CLICK                       1041
#define IDC_MAPHELP                     1042
#define IDC_POPUPTEXT                   1043
#define IDC_SAVEATTACHMENTS             1044
#define CONN_OUT                        1045
#define MSGS_OUT                        1046
#define MSGS_IN                         1047
#define REJECTS_IN                      1048
#define REJECTS_OUT                     1049
#define BYTES_OUT                       1050
#define BYTES_IN                        1051
#define LASTCONNECT                     1052
#define CONN_IN                         1053
#define IDC_CHATCALLS                   1064
#define IDC_CHATCOLOURS                 1065
#define RMS_EXPRESS_USER                1066
#define RMS_SSID1                       1070
#define RMS_SSID2                       1071
#define RMS_SSID3                       1072
#define IDC_SYSTOSYSOPCALL              1073
#define IDC_HOLDFROM                    1074
#define IDC_DONTHOLDNEW                 1074
#define IDC_HOLDTO                      1075
#define IDC_HOLDAT                      1076
#define IDC_REJFROM                     1077
#define IDC_REJTO                       1078
#define IDC_REJAT                       1079
#define IDC_FILTERSAVE                  1080
#define IDC_OVERRIDEUNSENT              1081
#define IDC_MAILFOR                     1082
#define IDC_SENDWP                      1083
#define IDC_WPTYPE                      1085
#define IDC_WPTO                        1086
#define IDC_WPSAVE                      1087
#define IDC_PRINTMSG                    1088
#define ID_CHATAPPL                     2001
#define ID_CHATNODES                    2002
#define ID_STREAMS                      2004
#define IDM_DISCONNECT 2000
#define SAVENODES                       2100
#define SAVEWELCOME                     2101
#define ISP_SMTP_AUTH                   3009
#define IDC_FWDTIMES                    4008
#define IDC_HRHELP                      4101
#define IDC_WP                          5000
#define IDC_WPNAME                      5001
#define IDC_ZIP1                        5002
#define IDC_QTH1                        5003
#define IDC_HOMEBBS1                    5004
#define IDC_HOMEBBS2                    5005
#define IDC_QTH2                        5006
#define IDC_ZIP2                        5007
#define IDC_LASTSEEN                    5008
#define IDC_LASTMODIFIED                5009
#define IDC_TYPE                        5010
#define IDC_EMAIL                       5010
#define IDC_CHANGED                     5011
#define IDC_HOLDMAIL                    5011
#define IDC_SEEN                        5012
#define IDC_POLLRMS                     5012
#define IDC_SYSOP_IN_LM                 5013
#define FILTER_FROM                     6006
#define FILTER_TO                       6007
#define FILTER_VIA                      6008
#define IDC_EDITTEXT                    6104
#define IDC_SAVETOFILE                  6105
#define IDC_LOGLIFETIME                 9025
#define IDC_USEB1                       9876
#define IDC_READDRESSLOCAL              9877
#define IDC_READDRESSRXED               9878
#define IDC_ALLOWCOMP                   9879
#define IDC_WARNNOROUTE                 9881
#define IDD_MAINTRESULTS                30001
#define IDD_EDITWP                      30002
#define IDD_UICONFIG                    30003
#define IDD_MSGFROMCLIPBOARD            30004
#define IDD_HRHELP                      30005
#define IDD_EDITMSGTEXT                 30006
#define IDD_UPDATECHATMAP               30007
#define IDD_CHATCOLCONFIG               30008
#define IDM_USERS                       40001
#define IDM_FWD                         40002
#define IDM_MESSAGES                    40003
#define IDM_WRAPTEXT                    40004
#define IDM_WARNINPUT                   40005
#define IDM_Flash                       40006
#define IDM_CLOSEWINDOW                 40007
#define IDM_WP                          40008
#define IDC_SAVEWP                      40009
#define IDC_DELETEWP                    40010
#define IDM_DEBUG                       40011
#define IDM_LOGBBS                      40012
#define IDM_LOGTCP                      40013
#define IDM_LOGCHAT                     40014
#define ID_ACTIONS_SENDMSGFROMCLIPBOARD 40015
#define IDM_CHATCONSOLE                 40016
#define ID_ACTIONS_UPDATECHATMAPINFO    40017
#define IDM_EDITCHATCOLOURS             40018
#define BPQSAVEREG                      40019
#define RESCANMSGS                      40020
#define ID_HELP_ONLINEHELP              40021
#define ID_ACTIONS_SENDMESSAGE          40022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        30009
#define _APS_NEXT_COMMAND_VALUE         40023
#define _APS_NEXT_CONTROL_VALUE         1089
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
